#!/bin/bash
sudo dpkg -r gazeboxbotplugin
sudo dpkg -r modelinterfacerbdl
sudo dpkg -r robotinterfaceros
sudo dpkg -r robotinterfacexbotrt
sudo dpkg -r xbotcore
sudo dpkg -r xbotinterface
sudo dpkg -r cartesian_interface
sudo dpkg -r matlogger2
sudo dpkg -r open_sot
sudo dpkg -r xbot_msgs
